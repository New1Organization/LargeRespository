
using System;

public class HardCodedCredentials
{
    //BAD

    const string username = "admin";
    const string password = "Test1029test";
    const string pass = "1234";

    bool isAdmin = username.Equals("admin");
    bool isPassCorrect = (pass == "1234");


    public void doActions()
    {
        if (getValue("pwd") != "admin123")
        {
            Console.WriteLine("Not PWD");
        }

        if (password != "Test1029test")
        {
            Console.WriteLine("Not Equal");
        }

        if (getPassword() == "admin123@")
        {
            Console.WriteLine("Equal");
        }

        var has_password = true;
    }


public string getValue(string key)
    {
        if (key == "pwd")
        {
            return "1234";
        }

        return "admin";

    }
    public string getPassword()
    {
        return "admin123@";
    }

}
