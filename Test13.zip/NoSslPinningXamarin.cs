using System;
using System.Net;
using System.Web;
 
public class XSSHandler
{
    static void Main(string[] args)
    {
        ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true; //TP
        ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, error) => { return true; }; //TP
        ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, error) => { Console.WriteLine("code"); return true; }; //Shouldn't be found
        ServicePointManager.ServerCertificateValidationCallback += 
        (sender, cert, chain, error) => { Console.WriteLine("code"); Console.WriteLine("mroe code"); Console.WriteLine("even more code");
            return true; }; //Shouldn't be found
         ServicePointManager.ServerCertificateValidationCallback = 
        (send,cert4,chain2,error) => { return true; }; //TP
        ServicePointManager.ServerCertificateValidationCallback = delegate { return true; }; //TP
        ServicePointManager.ServerCertificateValidationCallback = delegate { if(1==1) return false; return true; }; //Shouldn't be found
        ServicePointManager.ServerCertificateValidationCallback = 
        delegate { return true; }; //TP
        ServicePointManager.ServerCertificateValidationCallback +=
   			 (sender, certificate, chain, errors) => {
        		return true;
    		}; //TP
    	ServicePointManager.ServerCertificateValidationCallback +=
   			 (sender, certificate, chain, errors) => {
        		return false;
    	}; //Shouldn't be found

		
    }
}