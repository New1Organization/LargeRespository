using System.Security.Cryptography;
class WeakHashingXamarin
{
    static void SHA1generateSHA1()
    {
		MD5CryptoServiceProvider md5ServiceProvider = new MD5CryptoServiceProvider();
		HMACMD5 hMacMD5 = new HMACMD5();
		RC2CryptoServiceProvider rc2ServiceProvider = new RC2CryptoServiceProvider();
		DESCryptoServiceProvider desServiceProvider = new DESCryptoServiceProvider();
		TripleDESCryptoServiceProvider tripleDesServiceProvider = new TripleDESCryptoServiceProvider();
		SHA1CryptoServiceProvider sha1ServiceProvider = new SHA1CryptoServiceProvider();
		SHA1Managed sha1Managed = new SHA1Managed();
		HMACSHA1 hMacSha1 = new HMACSHA1();
		var hashAlg = MD5.Create();
		var hashAlg1 = RC2.Create();
		var hashAlg2 = DES.Create();
		var hashAlg3 = TripleDES.Create();
		var hashAlg4 = SHA1.Create();
		//var hashAlg5 = RIPEMD160.Create(); Valid on for Xamarin.Android
    }
}