using System;
using System.Security.Cryptography;
class WeakHashing
{
    static void SHA1generateSHA1()
    {
		RijndaelManaged ijndaelManaged = new RijndaelManaged
		{
            Mode = CipherMode.ECB //TP
        };
		TripleDES tripleDes = new TripleDESCng
        {
            Mode = CipherMode.OFB //TP
        };
		TripleDES tripleDes2 = new TripleDESCng
        {
            Mode = CipherMode.CFB //TP
        };
		
		Console.WriteLine(CipherMode.ECB); //FP
    }
}