using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace TestNamespace
{
    public partial class WebForm
    {
        public static string ConnectionString { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {

            string name = "product_name";
            
            //Bad
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
               
                SqlCommand sqlCommand = new SqlCommand()
                {
                    CommandText = "SELECT ProductId FROM Products WHERE ProductName = '" + name + "'",
                    CommandType = CommandType.Text,
                };

                SqlDataReader reader = sqlCommand.ExecuteReader();
            }
            
            //Good
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
               
                SqlCommand sqlCommand = new SqlCommand()
                {
                    CommandText = "SELECT ProductId FROM Products WHERE ProductName = @NAME",
                    CommandType = CommandType.Text,
                };
                
                sqlCommand.Parameters.Add("@NAME", SqlDbType.NVarChar);
                sqlCommand.Parameters["@NAME"].Value = name;

                SqlDataReader reader = sqlCommand.ExecuteReader();
            }
        }
    }
}