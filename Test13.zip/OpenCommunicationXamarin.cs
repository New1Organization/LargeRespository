using Microsoft.AspNetCore.Http;
using System;
using System.Net.Http;
using System.Web;

public class OpenCommunicationExample 
{
    static HttpClient client = new HttpClient();
    public async System.Threading.Tasks.Task doRequestAsync()
    {
        HttpResponseMessage response = await client.GetAsync(new Uri (string.Format("http://www.google.com", string.Empty)));//TP

        HttpResponseMessage response1 = await client.GetAsync (new Uri (string.Format ("https://www.google.com", string.Empty)));//Shouldn't be found
    }
}