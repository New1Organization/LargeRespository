using Microsoft.AspNetCore.Http;
using System;
using System.Web;
 
public class CrossSiteScriptingXamarin : ServiceStack.Host.IHttpHandler
{
    public void ProcessRequest(HttpContext ctx)
    {
   		 //TP
        ctx.Response.WriteAsync("The page \"" + ctx.Request.Query["page"] + "\" was not found.");
        
        //Not an Vulernability
        ctx.Response.WriteAsync("The page was not found.");
    }
}